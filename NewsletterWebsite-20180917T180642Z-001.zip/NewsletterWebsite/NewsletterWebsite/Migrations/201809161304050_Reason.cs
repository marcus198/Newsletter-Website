namespace NewsletterWebsite.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Reason : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.NewsletterModels", "Reason", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.NewsletterModels", "Reason");
        }
    }
}
