﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace NewsletterWebsite.Models
{
    public class NewsletterModel
    {
        [Key]
        [Required]
        public int PersonId { get; set; }

        [Required(ErrorMessage = "First Name required")]
        [Display(Name = "First Name (Required)")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name required")]
        [Display(Name = "Last Name (Required)")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Address required")]
        [Display(Name = "Address (Required)")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Email required")]
        [Display(Name = "Email (Required)")]
        [EmailAddress]
        public string Email { get; set; }

        [Required(ErrorMessage = "Phone number required")]
        [Display(Name = "Phone Number (Required)")]
        public long PhoneNumber { get; set; }

        [Required]
        [Range(1, 3, ErrorMessage = "Please tell us how you heard about us")]
        [Display(Name = "How You Heard About Us (Required)")] 
        public int HeardAbout { get; set; }

        [Display(Name = "Reason for Signing Up (Optional)")]
        public string Reason { get; set; }
    }
    public class NewsletterContext : DbContext
    {
        public DbSet<NewsletterModel> Newsletters { get; set; }
    }
}