﻿using NewsletterWebsite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using PagedList;
using System.Configuration;
using System.Net.Mail;

namespace NewsletterWebsite.Controllers
{
    public class NewsletterController : Controller
    {
        private NewsletterContext mDataContext;
        public string name = "";
        public string surName = "";
        public string addr = "";
        public string emailAddr = "";

        public NewsletterController()

        {

            mDataContext = new NewsletterContext();

        }
        //GET: Subscriber
        public ActionResult Index(String currentFilter, String sortOrder, int? page)
        {
            var names = from a in mDataContext.Newsletters select a;

            if (name != "")
            {
                names = mDataContext.Newsletters.Where(a => a.FirstName.Contains(name));
            }

            ViewBag.FirstNameSortParm = String.IsNullOrEmpty(sortOrder) ? "firstName_desc" : "";
            ViewBag.LastNameSortParm = sortOrder == "LastName" ? "lastName_desc" : "LastName";

            // Sort names alphabetically
            switch (sortOrder)
            {
                case "firstName_desc":
                    names = names.OrderByDescending(a => a.FirstName);
                    break;
                case "LastName":
                    names = names.OrderBy(a => a.LastName);
                    break;
                case "lastName_desc":
                    names = names.OrderByDescending(a => a.LastName);
                    break;
                default:
                    names = names.OrderBy(a => a.PersonId);
                    break;
            }


            if (surName != "")
            {
                names = mDataContext.Newsletters.Where(a => a.LastName.Contains(surName));
            }
            if (addr != "")
            {
                names = mDataContext.Newsletters.Where(a => a.Address.Contains(addr));
            }

            var pageNumber = page ?? 1;
            try
            {
                var onePageOfProducts = names.ToPagedList(pageNumber, 10);
                ViewBag.OnePageOfProducts = onePageOfProducts;
            }
            catch (Exception ex)
            {
               var errormsg = ex.InnerException.ToString();
                Console.Write(errormsg);
            }                      
            return View();
        }


        [HttpGet]

        public ActionResult AddPerson()

        {
            return View();

        }
        [HttpPost]

        public ActionResult AddPerson(NewsletterModel newsletter)
        {
            //Check if email address has already been added to the database
            var email = mDataContext.Newsletters.Where(x => x.Email == newsletter.Email).FirstOrDefault();

            if (ModelState.IsValid) // If all required data is entered in the proper format
            {           
                mDataContext.Newsletters.Add(newsletter);
                if (email == null)
                {
                    MailMessage mail = new MailMessage("marcus.russell.test@gmail.com", newsletter.Email, "Welcome " + newsletter.FirstName, "Hi " + newsletter.FirstName + ", \nThank you for signing up to our newsletter!");
                    SmtpClient client = new SmtpClient("smtp.gmail.com");
                    client.Port = 587;
                    client.Credentials = new System.Net.NetworkCredential("marcus.russell.test@gmail.com", "qwertyui12345678");
                    client.EnableSsl = true;
                    client.Send(mail);  // Send a notofication email to the subscriber
                    mDataContext.SaveChanges();
                }
                else
                {
                    // Tell subscriber that email already stored in database, so record not entered
                    return RedirectToAction("ErrorEmail");
                }
            }
            else
            {
                // NOt all required fields proplery filled out
                return View("AddPerson");
            }
            // Notify the subscriber that they have successfully signed up
            return RedirectToAction("Welcome");

        }
        public ActionResult Welcome(int id = 0)
        {
            return View(mDataContext.Newsletters.Find(id));
        }
        public ActionResult ErrorEmail(int id = 0)
        {
            return View(mDataContext.Newsletters.Find(id));
        }
        public ActionResult AddPersonView()
        {
            return RedirectToAction("AddPerson");
        }

        public ActionResult Details(int id = 0)
        {
            return View(mDataContext.Newsletters.Find(id));
        }
        public ActionResult Edit(int id = 0)
        {
            return View(mDataContext.Newsletters.Find(id));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Edit(NewsletterModel e)
        {
            mDataContext.Entry(e).State = System.Data.Entity.EntityState.Modified;
            mDataContext.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id = 0)
        {
            return View(mDataContext.Newsletters.Find(id));
        }


        [HttpPost, ActionName("Delete")]
        public ActionResult DeletePerson(int id)
        {
            NewsletterModel newsletter = mDataContext.Newsletters.Find(id);
            mDataContext.Newsletters.Remove(newsletter);
            mDataContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}